

const bans = await d3.json("bans.json");
const books = await d3.json("books.json");
const districtSums = await d3.json("district_breakdown.json");
const stateSums = await d3.json("states_breakdown.json");

function filterDistrict(dist) {
  var bansByDist = d3.group(bans, d => d.District)
  var districtBans = bansByDist.get(dist)
  var titles = []
  districtBans.forEach((ban) => {
    var toAppend = [ban.Title, ban.Author]
    if (!titles.includes(toAppend)) {
      titles.push([ban.Title, ban.Author])
    }
  })
  var toReturn = books.filter(function(d,i) { 
    return titles.some((title) =>{
      return d.Title == title[0] && d.Author == title[1]
    })
  })
  return toReturn
}

function filterState(state) {
  var bansByState = d3.group(bans, d => d.State)
  var stateBans = bansByState.get(state)
  var titles = []
    stateBans.forEach((ban) => {
    var toAppend = [ban.Title, ban.Author]
    if (!titles.includes(toAppend)) {
      titles.push([ban.Title, ban.Author])
    }
  })
  var toReturn = books.filter(function(d,i) { 
    return titles.some((title) => {
      return d.Title == title[0] && d.Author == title[1]
    })
  })
  return toReturn
}

function filterSubj(arr) {
  var toReturn = books.filter(function(d,i) { 
    return arr.every((tag) => {
      return d.Tags.includes(tag)
    })
  })
  return toReturn
}

function search(text) {
  var toReturn = books.filter(function(d,i) { 
    return (d.Categories.toLowerCase().includes(text) || d.Title.toLowerCase().includes(text) || d.Author.toLowerCase().includes(text) || d.Description.toLowerCase().includes(text))
  })
  return toReturn
}

function timesBanned(title, author, state='US') {
  var bansByState = d3.group(bans, d => d.State)
  var stateBans = bansByState.get(state)
  var banSet = bans
  if (state != 'US') {
    banSet = stateBans
  }
  return banSet.filter(function(d,i) {
    return d.Title.toLowerCase() == title.toLowerCase() && d.Author.toLowerCase() == author.toLowerCase()
  }).length
}

// console.log(filterDistrict('Ankeny Community School District'))
console.log(filterState('Tennessee'))
// console.log(filterSubj(['Social Topics', 'Juvenile Nonfiction']))
// console.log(search('gender'))


// console.log(timesBanned('the bluest eye', 'Morrison, Toni'))


const waffle = d3.select('.waffle');
const myState = 'Florida'
const filteredBooks = filterState(myState)
var sortedBooks = filteredBooks.slice().sort((a, b) => d3.descending(timesBanned(a.Title, a.Author, myState), timesBanned(b.Title, b.Author, myState)))


waffle
  .selectAll('.block')
  .data(sortedBooks)
  .enter()
  .append('div')
  .attr('class', 'block')
  .style('background-image', d => (d.Image != 0 ? "url('" + d.Images.thumbnail + "')" : "url('https://upload.wikimedia.org/wikipedia/commons/thumb/6/65/No-Image-Placeholder.svg/660px-No-Image-Placeholder.svg.png?20200912122019')"))
  .style('background-position', 'center top')
  .style('background-size', 'cover')
  .style('border-color', d => (d.Maturity == "MATURE" ? "red" : "black"))
  .on("click", (event) => console.log(event.target.__data__))
  .insert("p")
  .attr('class', 'title')
  .html(d => d.Title + "<br> <small>" + d.Author + "</small> <br> <small>" + timesBanned(d.Title, d.Author, myState) + " bans</small>")

console.log(filteredBooks)